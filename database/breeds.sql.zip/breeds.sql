-- phpMyAdmin SQL Dump
-- version 4.4.10
-- http://www.phpmyadmin.net
--
-- Хост: localhost:3306
-- Время создания: Янв 12 2019 г., 13:46
-- Версия сервера: 5.5.42
-- Версия PHP: 5.6.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `myblog.loc`
--

-- --------------------------------------------------------

--
-- Структура таблицы `breeds`
--

CREATE TABLE `breeds` (
  `id` int(11) NOT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `short_content` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `content` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `category_id` int(11) NOT NULL,
  `author_id` int(11) NOT NULL,
  `image` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `status` int(1) NOT NULL DEFAULT '1'
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `breeds`
--

INSERT INTO `breeds` (`id`, `title`, `short_content`, `content`, `category_id`, `author_id`, `image`, `date`, `status`) VALUES
(2, 'текст', '', 'Ð²Ð°Ð²Ð°Ð²Ð°', 0, 0, '', '2019-01-12 10:18:54', 1),
(3, 'ÐºÐµÐµÐºÐµ', '', 'ÐµÐºÐµÐºÐµÐº', 0, 0, 'Array', '2019-01-12 12:19:33', 1),
(4, 'ytytyfdf', '', 'ytytytyÐ²Ð°Ð²Ð°', 0, 0, 'Array', '2019-01-12 12:20:55', 1),
(5, 'ytytyfdf', '', 'ytytytyÐ²Ð°Ð²Ð°', 0, 0, 'Array', '2019-01-12 12:21:13', 1),
(6, 'ytytyfdf', '', 'ytytytyÐ²Ð°Ð²Ð°', 0, 0, 'Array', '2019-01-12 12:21:53', 1),
(7, 'ytytyfdf', '', 'ytytytyÐ²Ð°Ð²Ð°', 0, 0, 'Array', '2019-01-12 12:21:54', 1),
(8, 'ytytyfdf', '', 'ytytytyÐ²Ð°Ð²Ð°', 0, 0, 'Array', '2019-01-12 12:21:55', 1),
(9, 'ytytyfdf', '', 'ytytytyÐ²Ð°Ð²Ð°', 0, 0, 'Array', '2019-01-12 12:21:55', 1),
(10, 'ytytyfdf', '', 'ytytytyÐ²Ð°Ð²Ð°', 0, 0, 'Array', '2019-01-12 12:21:55', 1),
(11, 'ytytyfdf', '', 'ytytytyÐ²Ð°Ð²Ð°', 0, 0, 'Array', '2019-01-12 12:21:55', 1),
(12, 'ytytyfdf', '', 'ytytytyÐ²Ð°Ð²Ð°', 0, 0, 'Array', '2019-01-12 12:21:56', 1),
(13, 'ytytyfdf', '', 'ytytytyÐ²Ð°Ð²Ð°', 0, 0, 'Array', '2019-01-12 12:21:56', 1),
(14, 'ytytyfdf', '', 'ytytytyÐ²Ð°Ð²Ð°', 0, 0, 'Array', '2019-01-12 12:21:56', 1),
(15, 'ytytyfdf', '', 'ytytytyÐ²Ð°Ð²Ð°', 0, 0, 'Array', '2019-01-12 12:22:56', 1),
(16, 'ytytyfdf', '', 'ytytytyÐ²Ð°Ð²Ð°', 0, 0, 'Array', '2019-01-12 12:23:11', 1),
(17, 'ytytyfdf', '', 'ytytytyÐ²Ð°Ð²Ð°', 0, 0, 'Array', '2019-01-12 12:23:20', 1),
(18, 'ytytyfdf', '', 'ytytytyÐ²Ð°Ð²Ð°', 0, 0, 'Array', '2019-01-12 12:24:13', 1),
(19, '11111111ÐºÐºÐºÐº', '', '111111111ÐºÐºÐºÐº', 0, 0, 'Array', '2019-01-12 12:38:22', 1),
(20, '11111111ÐºÐºÐºÐº', '', '111111111ÐºÐºÐºÐº', 0, 0, 'Array', '2019-01-12 12:42:13', 1),
(21, '11111111ÐºÐºÐºÐº', '', '111111111ÐºÐºÐºÐº', 0, 0, 'Array', '2019-01-12 12:42:33', 1);

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `breeds`
--
ALTER TABLE `breeds`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `breeds`
--
ALTER TABLE `breeds`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=22;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
